var async = require("asynchron");
var apersistence = require("../../apersistence/lib/abstractPersistence.js");
var modelUtil = require ("../../apersistence/lib/ModelDescription");
var redis = require("redis");

var redisConnection = async.bindAllMembers(redis.createClient());
var persistence = apersistence.createRedisPersistence(redisConnection);

var audit = require('./nodes/audit')
var storage = require('./nodes/storage')
var index = require('./nodes/index')

var storage_nodes = []

var owner = 'ioana.bogdan@gmail.com'
var password = 'cesafacin-aicesafaci'
var num = 2
persistence.registerModel("PDS", {
    description: {
        type:'string',
        pk:true,
        index: true
    },
    KR: {
        type:'string'
    },
},function(){});

storage.createStorageNodesPool(num, function(err, res) {
    storage_nodes = res
})


// audit.store_phase1(owner, function(err, res_store) {

//     // console.log(res);
//     splitted = chunkify(password, num, true)
//     keys = [];
//     processed = 0
//     for(var i = 0; i < num; ++i) {
//         console.log("I", i)
//         processed++;
//         storage.store_chunk("Storage" + (i+1), storage_nodes["Storage" + (i+1)], splitted[i], function(err, res) {
//             if(typeof(res) === 'string')  {
//                 keys.push(res);
//             }
//             if(processed == num) {
//                 console.log(processed, num)
//                 console.log("!!!!!", res_store)
//                 index.store(res_store.MK, keys, function(err, res) {
//                     ;
//                 });
//                 var object = persistence.lookup.async('PDS', owner);
//                 (function(object) {

//                     object.KR = res_store.KR;
//                     object.description = owner
        

//                     console.log("================SAVE PDS================\n")
//                     persistence.saveObject(object, function(err, res) {
//                         console.log("OBJECT:");
//                         console.log(res.__meta.savedValues);
//                         console.log("\n\n");
//                         callback(null, PK)
//                     });
//                 }).wait(object);
//             }
//         })
//     }    
// })



function retrieve(owner) {
    persistence.filter("PDS", {"description": owner}, function(err, res) {
        audit.retrieve(res[0].__meta.KR, storage_nodes, function(err, res) {
            console.log("????", res)
        })
    })
}



retrieve(owner, storage_nodes)


function chcunkify(a, n, balanced) {
    
    if (n < 2)
        return [a];

    var len = a.length,
            out = [],
            i = 0,
            size;

    if (len % n === 0) {
        size = Math.floor(len / n);
        while (i < len) {
            out.push(a.slice(i, i += size));
        }
    }

    else if (balanced) {
        while (i < len) {
            size = Math.ceil((len - i) / n--);
            out.push(a.slice(i, i += size));
        }
    }

    else {

        n--;
        size = Math.floor(len / n);
        if (len % size === 0)
            size--;
        while (i < size * n) {
            out.push(a.slice(i, i += size));
        }
        out.push(a.slice(size * n));

    }

    return out;
}


