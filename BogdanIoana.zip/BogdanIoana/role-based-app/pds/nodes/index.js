var async = require("asynchron");
var apersistence = require("../../../apersistence/lib/abstractPersistence.js");
var modelUtil = require ("../../../apersistence/lib/ModelDescription");
var redis = require("redis");

var redisConnection = async.bindAllMembers(redis.createClient('7003'));
var persistence = apersistence.createRedisPersistence(redisConnection);


persistence.registerModel("index", {
    MK: {
        type:'string',
        pk:true,
        index: true
    },
    data: {
        type:'array',
    },
},function(){});

function generate_random_uuid() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

exports.store = function(MK, keys, callback) {
    var object = persistence.lookup.async("index", MK);
    (function(object) {

        object.MK = MK;
        object.data = keys;
        
        persistence.saveObject(object, function(err, res) {
            callback(null, null);
        });
    

    }).wait(object);
}

exports.retrieve = function(MK, store_nodes, callback) {
    persistence.filter('index', {"MK": MK}, function(err, res) {
        callback(null, res[0].__meta.data)
    })
}