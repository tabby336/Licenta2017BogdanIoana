var async = require("asynchron");
var apersistence = require("../../../apersistence/lib/abstractPersistence.js");
var modelUtil = require ("../../../apersistence/lib/ModelDescription");
var redis = require("redis");

persistences = {}
port = 7000

function generate_random_uuid() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

exports.createStorageNodesPool = function (num, callback){
	processed = 0
	for(var i = 1; i <= num; ++i) {
		var redisConnection = async.bindAllMembers(redis.createClient(port + i));
		var persistence = apersistence.createRedisPersistence(redisConnection)
		persistence.registerModel("Storage"+i, {
		    PK: {
		        type:'string',
		        pk:true,
		        index: true
		    },
		    PD: {
		        type:'string',
		    }
		},function(){});
		persistences["Storage"+i] = persistence
		processed++;
		if(processed == num) {
			callback(null, persistences)
		}
	}
}

exports.store_chunk = function(typeName, conn, chunk, callback) {
	var PK = generate_random_uuid();
    var object = conn.lookup.async(typeName, chunk);
    (function(object) {

	    object.PK = PK;
	    object.PD = chunk
	    
	    conn.saveObject(object, function(err, res) {
	        callback(null, PK)
	    });
	}).wait(object);
}


exports.retrieve = function(typeName, conn, PK, callback) {
	conn.filter(typeName, {"PK": PK}, function(err, res) {
		callback(null, res[0].__meta.PD);
	})
}