var async = require("asynchron");
var apersistence = require("../../../apersistence/lib/abstractPersistence.js");
var modelUtil = require ("../../../apersistence/lib/ModelDescription");
var redis = require("redis");

var redisConnection = async.bindAllMembers(redis.createClient('7000'));
var persistence = apersistence.createRedisPersistence(redisConnection);

var index = require('./index')
var storage = require('./storage')

persistence.registerModel("audit", {
    KR: {
        type:'string',
        pk:true,
        index: true
    },
    data: {
        type:'array',
    },
},function(){});

function generate_random_uuid() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

exports.store_phase1 = function(data_owner, callback) {
    var MK = generate_random_uuid();
    var KR = generate_random_uuid();
    var object = persistence.lookup.async("audit", data_owner);
    (function(object) {

    object.KR = KR;
    object.data = [MK, data_owner]
    
    persistence.saveObject(object, function(err, res) {
        callback(null, {'MK': MK, 'KR': KR})
    });
    

}).wait(object);

}


exports.retrieve = function(KR, storage_nodes, callback) {
    data = ''
    processed = 0;
    persistence.filter("audit", {'KR': KR}, function(err, res) {
        var MK = res[0].__meta.data[0]
        index.retrieve(MK, storage_nodes, function(err, res) {
            var PKis = res;
            for(var i=0; i < PKis.length; ++i) {
                storage.retrieve("Storage" + (i+1), storage_nodes["Storage" + (i+1)], PKis[i], function(err, res) {
                    processed++;
                    data += res
                    if(processed == PKis.length){
                        callback(null, data)
                    }
                    
                })
                
            }
        })
    })
}