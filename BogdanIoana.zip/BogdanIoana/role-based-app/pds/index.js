var async = require("asynchron");
var apersistence = require("../../apersistence/lib/abstractPersistence.js");
var modelUtil = require ("../../apersistence/lib/ModelDescription");
var redis = require("redis");

var redisConnection = async.bindAllMembers(redis.createClient());
var persistence = apersistence.createRedisPersistence(redisConnection);
var users = require("../users")

persistence.registerModel("PDS", {
    description: {
        type:'string',
        default:"no name",
        pk:true,
        index: true
    },
    password: {
        type:'string',
        default:'default_password',
    },
},function(){});

exports.add_new_user = function(email, callback) {
	persistence.filter("PDS", {"description":email}, function(err, res) {
		if(res.length) {
			return callback(null, "placeholder")
		} else {
			var employee = persistence.lookup.async("PDS", email);
			(function(employee){
			    employee.email = email
			    persistence.saveObject(employee, function(err, res) {
			        savedValues = res.__meta.savedValues;
			        if(savedValues.email == email && savedValues.password == 'default_password')
			       	 	return callback(null, true)
			        else
			        	return callback(null, false)
			    });
			}).wait(employee);	
		}
	});
}

exports.add_new_password = function(desc, password, callback) {
	// persistence.filer("PDS", {"description": desc}, function(err, res) {
	// 	if(res.length) {
	// 		callback(null, true)
	// 	}
	// })
	var object = modelUtil.createObjectFromData("PDS", {"description": desc, "password": password})
	persistence.saveObject(object, function(err, res) {
		callback(null, true)
	})
}


exports.check_login = function(creds, callback) {
	persistence.filter("PDS", {"description":creds.email}, function(err, res) {
		if(!res.length) {
			return callback(null, "placeholder");
		} else {
			if(res[0].password == creds.password)
				if(creds.password == 'default_password') {
					return callback(null, 'change')
				} else {
					return callback(null, true)
				}
			else 
				return callback(null, false)
		}
	})
}

exports.get_user_passwords = function(email, dep, callback) {
	var passwords = {}
	persistence.filter("PDS", {"description": email}, function(err, res) {
		console.log(dep)
		// console.log("REEES", res[0].__meta.password)
		if(res[0] === undefined) {
			passwords.own = 'default_password'
		} else {
			passwords.own = res[0].__meta.password;	
		}
		
		persistence.filter("PDS", {"description": dep}, function(err, resp) {
			console.log("My passwords", passwords)
			passwords.department = resp[0].password
			console.log("My passwords2", passwords)
			callback(null, passwords)
		})
	})
}


exports.change_password = function(creds, callback) {
	if(creds.password != creds.vpassword) {
		return callback(null, false);
	} else {
		console.log("pamx")
		var object = modelUtil.createObjectFromData("PDS", {"description": creds.email, "password": creds.password})
		users.get_user_info(creds.email, creds.email, function(err, res) {
			res.__password = creds.password;
			console.log("RES IN CHANGE PWD", res)
			users.update_user_info(res, function(err, resp) {
				persistence.saveObject(object, function(err, resp2) {
					callback(null, true);
				});	
			})
		});
	};
}

