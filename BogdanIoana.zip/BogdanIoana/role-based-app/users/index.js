var async = require("asynchron");
var apersistence = require("../../apersistence/lib/abstractPersistence.js");
var modelUtil = require ("../../apersistence/lib/ModelDescription");
var redis = require("redis");

var redisConnection = async.bindAllMembers(redis.createClient(7777, '127.0.0.1'));
var persistence = apersistence.createRedisPersistence(redisConnection);

var pds = require('../pds')

persistence.registerModel("Users", {
    email: {
        type:'string',
        default:"no name",
        pk:true,
    },
    name: {
        type:'string',
        default:"John",
        index: true
    },
    lastname: {
    	type: 'string',
        default:"Doe",
        index: true
    },
    info: {
    	type: 'string',
    	default: 'tell us more',
        security: 'eq'
    },
    salary: {
    	type: 'int',
    	default: 100,
        security: 'eq'
    },
    directRespondant: {
    	type: 'string',
    	default: 'admin@admin.com'
    },
    phone: {
    	type: 'string',
    	default: 'None',
        security: 'eq'
    },
    department: {
    	type: 'string',
    	default: 'none'
    },
    profilePic: {
        type: 'string',
        default: 'images/default.gif'
    }
},function(){});

exports.add_new_user = function(info, callback) {
    pds.get_user_passwords(info.email, info.department, function(err, passwords) {
    	persistence.filter("Users", {"email":info.email}, function(err, res) {
    		if(res.length) {
    			callback(null, "placeholder")
    		} else {
    			var employee = persistence.lookup.async("Users", info.email);
    			(function(employee){
    			    for(var i in info) {
    			    	employee[i] = info[i]
    			    }
                    
                    employee.key = {
                        "info": passwords.department,
                        "phone": passwords.department,
                        "salary": passwords.own
                    }
                    console.log("employee to add", employee)
    			    persistence.saveObject(employee, function(err, res) {
    			        savedValues = res.__meta.savedValues;
    			        callback(null, true)
    			    });
    			}).wait(employee);	
    		}
    	});
    })
    callback(null, true)
}


exports.update_user_info = function(info, callback) {
    var new_pwd = undefined
    if(info.__password) {// changed pwd
        new_pwd = info.__password
        delete info.__password
    }
    console.log("pam>")
    pds.get_user_passwords(info.email, info.department, function(err, resp) {
        keys = {
            "phone": resp.department,
            "info": resp.department,
            "salary": resp.own
        }
        console.log("KEYS", keys)
        persistence.filter("Users", {"email": info.email, "__passwords": keys}, function(err, res) {
            console.log("IN FILTER UPDATE USER INFO")
            console.log(res)
            var employee = persistence.lookup.async("Users", info.email);
            (function(employee) {
                for(var i in info) {
                    employee[i] = info[i]
                }
                employee.key = {"phone": resp.department, "info": resp.department, "salary": new_pwd || resp.own};
                console.log("In update")
                console.log(employee)
                persistence.saveObject(employee, function(err, respp) {
                    console.log("RESPP")
                    console.log(respp)
                    callback(null, true);
                })
            }).wait(employee);
        })
    })
    callback(null, true)
}

exports.get_user_department = function(email, callback) {
    console.log("??", email)
    persistence.filter("Users", {"email": email}, function(err, res) {
        console.log("??", res)
        callback(null, res[0].__meta.savedValues.department)
    })
}

exports.get_user_info = function(email, actual_email, callback) {
    console.log("pamx")
    exports.get_user_department(actual_email, function(err, dep) {
        console.log("pamx")
        pds.get_user_passwords(actual_email, dep, function(err, passwords) {
        	persistence.filter("Users", {"email": email, "__passwords": {"salary": passwords.own, "phone": passwords.department, "info": passwords.department}}, function(err, res) {
        		if(!res.length) {
        			callback(null, {})
        		} else {
                    if(res[0].__meta.savedValues.email == actual_email) {
                        console.log(res)
                        res[0].__meta.savedValues.salary = 100
                    } else {
                        res[0].__meta.savedValues.salary = 'error'
                    }
        			callback(null, res[0].__meta.savedValues);
        		}
        	})
        })
    })
}

exports.get_user_respondant = function(email, callback) {
    persistence.filter("Users", {"email": email}, function(err, res) {
        if(res[0] !== undefined) {
            persistence.filter("Users", {"email": res[0].__meta.savedValues.directRespondant}, function(err, resp) {
                if(resp[0] !== undefined)
                    callback(null, resp[0].__meta.savedValues)
                else callback(null, {})
            })
        }
    })
}

exports.get_user_colleagues = function(boss_email, callback) {
    persistence.filter("Users", {"directRespondant": boss_email}, function (err, rest) {
        var arr = []
        for(var v in rest) {
            if(typeof(rest[v]) === 'object')
                arr.push(rest[v].__meta.savedValues)
        }
        callback(null, arr);
    })
}

