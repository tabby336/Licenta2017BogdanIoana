var redis = require('redis')
var client = redis.createClient(7777,'127.0.0.1')

var client2 = redis.createClient()


client.on("error", function (err) {
    console.log("Error " + err);
});

// console.log(client)
// 

client.hset("hash key", "hashtest 1", "some value", redis.print);
client2.hset("hash key", "hashtest 1", "some value", redis.print);
