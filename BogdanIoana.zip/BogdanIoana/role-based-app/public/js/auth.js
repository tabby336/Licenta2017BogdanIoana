$("#register_employee" ).on( "submit", function( event ) {
     event.preventDefault();
     console.log( $( this ).serialize() );
     $.ajax({
          type: "POST",
          url: "/register",
          data: $( this ).serialize(),
          success: function(data) {
               console.log(data);
               alert("Employee added successfully!")
               $( '#register_employee' ).each(function(){
                    this.reset();
               });

          },
          error: function(xhr, ajaxOptions, thrownError) {
               if (xhr.status == 500) {
                    alert('Adding new user failed.');
               } else if(xhr.status == 409) {
                    alert('Email address in use.')
               }
          }
     });
});

$('#login_employee').on( "submit", function ( event ) {
     event.preventDefault();
     console.log($( this ).serialize());
     $.ajax({
          type: "POST",
          url: "/login",
          data: $( this ).serialize(),
          success: function(data) {
               if(data == 'change') {
                    $( 'body' ).load('/change_passwd');
               } else {
                    $( 'body' ).load('/index');
               }
               
          },
          error: function(xhr, ajaxOptions, thrownError) {
               if (xhr.status == 401) {
                    alert('Login failed');
               }
          }
     })
});

$('#change_password').on( "submit", function ( event ) {
     event.preventDefault();
     console.log($( this ).serialize())
     $.ajax({
          type: "POST",
          url: "/change_passwd",
          data: $( this ).serialize(),
          success: function(data) {
               $( 'body' ).load('/index');
          },   
          error: function(xhr, ajaxOptions, throwError) {
               if (xhr.status == 500) {
                    alert('Changing password failed')
               }
          }
     });
});

