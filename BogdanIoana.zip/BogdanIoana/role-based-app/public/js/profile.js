$(document).ready( function () {
	var pathname = window.location.search; 
	console.log("??", pathname)
	if(pathname == "")  {
		$('#myprofile_list').hide();
		$('#edit').show();
	} else {
		$('#myprofile_list').show();
		$('#edit').hide();
	}
	get_info(pathname);
	$('#save').hide();
	$('#file-upload').hide();
});

function get_info(pathname) {
   	$.ajax({
        type: 'GET',
        url: '/get_user_info' + pathname,
        success: function(d) {
        	console.log(d)
        	data = d.me
            $('#name').text(data.name);
            $('#lastname').text(data.lastname)
            $('#department').text(data.department)
            $('#email').text(data.email)
            $('#info2').text(data.info)
            $('#directRespondant').text(data.directRespondant)
            $('#phone').text(data.phone)
            $('#salary').text(data.salary)


            if((typeof(d.directRespondant) == 'object') && (d.directRespondant.lastname != undefined)) {
            	resp = '  <div class="card-panel teal lighten-2"><h5>DIRECT RESPONDANT</h5></div><div class="cards-container">\
              		<div class="row valign-wrapper">\
    					<div class="col s12 offset-s1 valign">\
      						<div class="card">\
        						<div class="card-content">\
        							<div class="card-image">\
              							<img src="images/' + d.directRespondant.name + d.directRespondant.lastname +'.jpeg">\
            						</div>\
          							<span class="card-title">'+ d.directRespondant.name + ' '+d.directRespondant.lastname +'</span>\
      								<p>' + d.directRespondant.email + '</p>\
    							</div>\
        						<div class="card-action">\
          							<a href="/index?email=' + d.directRespondant.email + '">View profile</a>\
        						</div>\
      						</div>\
    					</div>\
  					</div></div>';
  					$('#colleagues').append(resp);
            }
            if(d.colleagues.length != 0) {
            	resp =  '<div class="card-panel teal lighten-2"><h5>COLLEAGUES</h5></div>'
            	$('#colleagues').append(resp);
            } 
        	resp = ''
  			for(var c = 0; c < d.colleagues.length; c = c+2) {
  				resp = '<div class="cards-container">\
              		<div class="row valign-wrapper">\
    					<div class="col s12 offset-s1 valign">\
      						<div class="card">\
        						<div class="card-content">\
        							<div class="card-image">\
              							<img src="images/' + d.colleagues[c].name + d.colleagues[c].lastname +'.jpeg">\
            						</div>\
          							<span class="card-title">'+ d.colleagues[c].name + ' '+d.colleagues[c].lastname +'</span>\
      								<p>' + d.colleagues[c].email + '</p>\
    							</div>\
        						<div class="card-action">\
          							<a href="/index?email=' + d.colleagues[c].email + '">View profile</a>\
        						</div>\
      						</div>\
    					</div>\
  					</div>';

  					if(c!= d.colleagues.length-1) {
  						resp += '<div class="row valign-wrapper">\
    					<div class="col s12 offset-s1 valign">\
      						<div class="card">\
        						<div class="card-content">\
        							<div class="card-image">\
              							<img src="images/' + d.colleagues[c+1].name + d.colleagues[c+1].lastname +'.jpeg">\
            						</div>\
          							<span class="card-title">'+ d.colleagues[c+1].name + ' '+d.colleagues[c+1].lastname +'</span>\
      								<p>' + d.colleagues[c+1].email + '</p>\
    							</div>\
        						<div class="card-action">\
          							<a href="/index?email=' + d.colleagues[c+1].email + '">View profile</a>\
        						</div>\
      						</div>\
    					</div>\
  					</div></div>'
  					} else {
  						resp += '</div>'
  					}
  				$('#colleagues').append(resp);
  			}
			if(d.subordinates.length != 0) {
        		resp =  '<div class="card-panel teal lighten-2"><h5>RESPONDING TO YOU</h5></div>'
        		$('#colleagues').append(resp);
        	} 
    		resp = ''
        	for(var c = 0; c < d.subordinates.length; c = c+2) {
  				resp = '<div class="cards-container">\
              		<div class="row valign-wrapper">\
    					<div class="col s12 offset-s1 valign">\
      						<div class="card">\
        						<div class="card-content">\
        							<div class="card-image">\
              							<img src="images/' + d.subordinates[c].name + d.subordinates[c].lastname +'.jpeg">\
            						</div>\
          							<span class="card-title">'+ d.subordinates[c].name + ' '+d.subordinates[c].lastname +'</span>\
      								<p>' + d.subordinates[c].email + '</p>\
    							</div>\
        						<div class="card-action">\
          							<a href="/index?email=' + d.subordinates[c].email + '">View profile</a>\
        						</div>\
      						</div>\
    					</div>\
  					</div>';

  					if(c!= d.subordinates.length-1) {
  						resp += '<div class="row valign-wrapper">\
    					<div class="col s12 offset-s1 valign">\
      						<div class="card">\
        						<div class="card-content">\
        							<div class="card-image">\
              							<img src="images/' + d.subordinates[c].name + d.subordinates[c].lastname +'.jpeg">\
            						</div>\
          							<span class="card-title">'+ d.subordinates[c+1].name + ' '+d.subordinates[c+1].lastname +'</span>\
      								<p>' + d.subordinates[c+1].email + '</p>\
    							</div>\
        						<div class="card-action">\
          							<a href="/index?email=' + d.subordinates[c+1].email + '">View profile</a>\
        						</div>\
      						</div>\
    					</div>\
  					</div></div>'
  					} else {
  						resp += '</div>'
  					}
  				$('#colleagues').append(resp);
  			}

        }
   	});
}

$('#edit').click( function(  ) {
	$('#edit').hide();
	$('#save').show();
	$('#file-upload').show();
	$("#firstname_div").html('<span class="info">First name: </span> <input name="name" value="' + $('#name').text() +'" id="name" type="text">');
	$('#lastname_div').html('<span class="info">Last name: </span> <input name="lastname" value="' + $('#lastname').text() + '" id="lastname" type="text">');
	$('#info_div').html('<span class="info">Aboue me: </span> <input name="info" value="' + $('#info2').text() + '" id="info2" type="text">');
	$('#phone_div').html('<span class="info">Phone number: </span> <input name="phone" value="' + $('#phone').text() + '" id="phone" type="text">');
});

$('#colleagues_list').click( function(  ) {
	$('#edit').hide();
	$('#save').hide();
});

$('#profile_list').click( function(  ) {
	if(! $('#profile').has('input').length ) {
		$('#edit').show();
		$('#save').hide();
	} else {
		$('#edit').hide();
		$('#save').show();
	}
})


$('#myprofile_list').click( function (  ) {
	$( 'body' ).load('/index')
	get_info("")
})

$('#logout').click( function (  ) {
	$.ajax({
		type: 'GET',
		url: '/logout',
		success: function(data) {
			$( 'body' ).load('/');
		}
	})
});


$('#upload-file-input').click( function(  ) {
	alert('paamm')
})

$('#save').click( function ( ) {
	$("#profile span").each( function( i, v ){
    	$this = $(this)
    	$("#profile").append(
        	$("<input type='hidden' />").attr({
            	name: $this.attr('id'),
            	value: $this.text()
        	})
    	)
	})
	$.ajax({
		type: 'POST',
		url: '/update_user_info',
		data: $('#profile').find('input').serialize(),
		success: function(data) {
			$( 'body' ).load('/index');
		},
		error: function(xhr, ajaxOptions, throwError) {
            if (xhr.status == 500) {
                alert('Changing password failed')
            }
        }

	});
});