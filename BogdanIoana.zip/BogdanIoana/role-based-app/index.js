var express = require('express'); 
var session = require('express-session');
var bodyParser = require('body-parser');

var pds = require('./pds')
var users = require('./users')

var app = express();
app.set('views', './views');

app.use(express.static(__dirname + '/public'))
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(session({ email: 'default', resave: false, saveUninitialized: true, secret: 'cats', cookie: { maxAge: 60000 }}))


app.engine('html', require('ejs').renderFile);
  
app.get('/', function (req, res) {
  res.render("login.html")
})
  
app.get('/admin', function(req, res) {
	res.render("admin.html")
})

app.get('/index', function(req, res) {
	res.render('index.html');		
})

app.get('/get_user_info', function(req,res) {
	var email = ''
	if(req.query.email !== undefined) {
		email = req.query.email
	} else {
		email = req.session.email
	}
	var d = {}
	users.get_user_info(email, req.session.email, function(err, resp) {
		d['me'] = resp;
		users.get_user_colleagues(resp['directRespondant'], function(err, resp2) {
			d['colleagues'] = resp2;
			users.get_user_respondant(email, function(err, resp3) {
				d['directRespondant'] = resp3;
				users.get_user_colleagues(email, function(err, resp4) {
					d['subordinates'] = resp4;
					res.send(d)
				})
			})
		});
	});
})


app.get('/change_passwd', function(req, res) {
	res.render('change_passwd.html')
})

app.post('/change_passwd', function(req, res) {
	pds.change_password(req.body, function(err, rest) {
		res.send("bravo boss");
	})
})

app.post('/register', function(req, res) {
	users.add_new_user(req.body, function(err, resp2) {
		pds.add_new_user(req.body.email, function(err,resp) {
			if(resp === true)
				res.status(200)
			else if(resp === false)
				res.status(500)
			else {
				res.status(409)
			}
			res.send('placeholder')
		});
	});
});

app.post('/update_user_info', function(req, res) {
	users.update_user_info(req.body, function(err, resp) {
		res.send('placeholder');
	})
})

app.post('/login', function(req, res) {
	pds.check_login(req.body, function(err, resp) {
		if (resp === true) {
			req.session.email = req.body.email;
			res.status(200)
			res.send('placeholder')
		} else if(resp === false){
			res.status(401)
			res.send('placeholder')
		} else if(resp === 'change') {
			req.session.email = req.body.email;
			res.status(200)
			res.send('change')
		}
	});
});

app.get('/logout', function(req, res) {
	delete req.session
	res.send("placeholder") 
})


pds.add_new_password('research', 'researchpassword', function(err, res) {
	console.log("Research department password added.");
})
pds.add_new_password('development', 'devpassword', function(err, res) {
	console.log("Development department password added.");
})
app.listen(3000);